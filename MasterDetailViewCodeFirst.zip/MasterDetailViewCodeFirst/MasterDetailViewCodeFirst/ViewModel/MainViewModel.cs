﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Threading;
using MasterDetailViewCodeFirst.Model.Entities;
using MasterDetailViewCodeFirst.Model.Service;

namespace MasterDetailViewCodeFirst.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel(IDataService dataService)
        {
            this.dataService = dataService;

            // Populate Customers
            GetCustomers();

            OrdersCollection = new ObservableCollection<Orders>();
            ProductCollection = new ObservableCollection<OrderDetails>();
        }
        public ObservableCollection<Customers> CustomersCollection
        {
            get
            {
                return customersCollection;
            }
            set
            {
                Set(ref customersCollection, value);
            }
        }
       
        public Customers SelectedCustomers
        {
            get { return selectedCustomers; }
            set
            {
                Set(ref selectedCustomers, value);
                GetOrdersAsync();
            }
        }

        public ObservableCollection<Orders> OrdersCollection
        {
            get
            {
                return ordersCollection;
            }
            set
            {
                Set(ref ordersCollection, value);
            }
        }
       
        public Orders SelectedOrder
        {
            get { return selectedOrder; }
            set
            {

                Set(ref selectedOrder, value);
                if (selectedOrder != null)
                {
                   GetProductsAsync();
                }
            }
        }
        public ObservableCollection<OrderDetails> ProductCollection
        {
            get
            {
                return productCollection;
            }
            set
            {
                Set(ref productCollection, value);
            }
        }


        private readonly IDataService dataService;
        private Customers selectedCustomers = null;
        private Orders selectedOrder = null;
        private ObservableCollection<OrderDetails> productCollection;
        private ObservableCollection<Orders> ordersCollection;
        private ObservableCollection<Customers> customersCollection;
        
        private async void GetCustomers()
        {
            if (this.IsInDesignMode)
            {
                var data = await dataService.GetCustomers();
                CustomersCollection = new ObservableCollection<Customers>(data);
            }

            await Task.Run(async () =>
            {
                var data = await dataService.GetCustomers();
                DispatcherHelper.CheckBeginInvokeOnUI(() =>
                {
                    CustomersCollection = new ObservableCollection<Customers>(data);
                });
            });
        }
        private async void GetOrdersAsync()
        {
            if (this.IsInDesignMode)
            {
                var data = await dataService.GetOrders(selectedCustomers.CustomerID);
                OrdersCollection = new ObservableCollection<Orders>(data);
            }

            await Task.Run(async () =>
            {
                var data = await dataService.GetOrders(selectedCustomers.CustomerID);
                DispatcherHelper.CheckBeginInvokeOnUI(() =>
                {
                    OrdersCollection = new ObservableCollection<Orders>(data);
                });
            });
        }

        private async void GetProductsAsync()
        {
            if (this.IsInDesignMode)
            {
                var data = await dataService.GetOrderDetails(selectedOrder.OrderID);
                ProductCollection = new ObservableCollection<OrderDetails>(data);
            }

            await Task.Run(async () =>
            {
                var data = await dataService.GetOrderDetails(selectedOrder.OrderID);
                DispatcherHelper.CheckBeginInvokeOnUI(() =>
                {
                    ProductCollection = new ObservableCollection<OrderDetails>(data);
                });
            }
            );
        }
    }
}