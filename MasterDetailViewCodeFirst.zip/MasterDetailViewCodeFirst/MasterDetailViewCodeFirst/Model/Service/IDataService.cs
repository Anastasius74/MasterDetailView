﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MasterDetailViewCodeFirst.Model.Entities;

namespace MasterDetailViewCodeFirst.Model.Service
{
    public interface IDataService
    {
        Task<IEnumerable<Customers>> GetCustomers();
        Task<IEnumerable<OrderDetails>> GetOrderDetails(object selectedOrderOrderId);
        Task<IEnumerable<Orders>> GetOrders(object selectedCustomersCustomerId);
    }
}
