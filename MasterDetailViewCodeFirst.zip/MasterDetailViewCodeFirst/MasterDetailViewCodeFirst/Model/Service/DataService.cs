﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MasterDetailViewCodeFirst.Model.Context;
using MasterDetailViewCodeFirst.Model.Entities;

namespace MasterDetailViewCodeFirst.Model.Service
{
    public class DataService : IDataService
    {
        private readonly NorthwindContextBase db;

        public DataService()
        {
            db = new NorthwindContext();
            db.Configuration.LazyLoadingEnabled = false;
            db.Configuration.AutoDetectChangesEnabled = false;
        }

        public async Task<IEnumerable<Customers>> GetCustomers()
        {
            return db.Customers;
        }

        public async Task<IEnumerable<Orders>> GetOrders(object customerId)
        {
            var ordersCollection = new List<Orders>();

            var query = (from order in db.Orders
                         where order.CustomerID == customerId
                         select order).ToList();
           
            foreach (Orders order in query)
            {
                ordersCollection.Add(order);
            }

            return ordersCollection;
        }

        public async Task<IEnumerable<OrderDetails>> GetOrderDetails(object orderId)
        {
            var productCollection = new List<OrderDetails>();

            int orderID = int.Parse(orderId.ToString());
            var query = (from orderDetails in db.OrderDetails
                         where orderDetails.OrderID == orderID
                         select orderDetails).ToList();           

            foreach (OrderDetails order in query)
            {
                productCollection.Add(order);
            }

            return productCollection;
        }
    }
}