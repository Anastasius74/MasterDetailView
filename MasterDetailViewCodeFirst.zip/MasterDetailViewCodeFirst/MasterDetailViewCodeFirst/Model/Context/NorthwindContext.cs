﻿using System.Data.Entity;
using MasterDetailViewCodeFirst.Model.Configuration;

namespace MasterDetailViewCodeFirst.Model.Context
{
    public class NorthwindContext : NorthwindContextBase
    {
        public NorthwindContext()
            : base()
        {
            Database.SetInitializer<NorthwindContext>(null);
        }

        public NorthwindContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {
            Database.SetInitializer<NorthwindContext>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new AddressDetailsConfiguration());
            modelBuilder.Configurations.Add(new CustomersConfiguration());
            modelBuilder.Configurations.Add(new EmployeesConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}
