﻿using System.Data.Entity.ModelConfiguration;
using MasterDetailViewCodeFirst.Model.Entities;

namespace MasterDetailViewCodeFirst.Model.Configuration
{
    public class EmployeesConfiguration : EntityTypeConfiguration<Employees>
    {
        public EmployeesConfiguration()
        {
            HasMany(x => x.Territories)
                .WithMany(x => x.Employees)
                .Map(m => m.MapLeftKey("EmployeeID")
                        .MapRightKey("TerritoryID")
                        .ToTable("EmployeeTerritories"));
        }
    }
}
