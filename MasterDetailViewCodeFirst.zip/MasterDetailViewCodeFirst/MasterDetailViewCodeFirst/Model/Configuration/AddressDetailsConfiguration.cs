﻿using System.Data.Entity.ModelConfiguration;
using MasterDetailViewCodeFirst.Model.Entities;

namespace MasterDetailViewCodeFirst.Model.Configuration
{
    public class AddressDetailsConfiguration : ComplexTypeConfiguration<AddressDetails>
    {
        public AddressDetailsConfiguration()
        {
            Property(x => x.Address).HasColumnName("Address");
            Property(x => x.City).HasColumnName("City");
            Property(x => x.Region).HasColumnName("Region");
            Property(x => x.PostalCode).HasColumnName("PostalCode");
            Property(x => x.Country).HasColumnName("Country");
        }
    }
}
