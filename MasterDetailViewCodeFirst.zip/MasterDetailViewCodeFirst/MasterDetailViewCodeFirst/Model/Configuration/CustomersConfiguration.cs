﻿using System.Data.Entity.ModelConfiguration;
using MasterDetailViewCodeFirst.Model.Entities;

namespace MasterDetailViewCodeFirst.Model.Configuration
{
    public class CustomersConfiguration : EntityTypeConfiguration<Customers>
    {
        public CustomersConfiguration()
        {
            HasMany(x => x.CustomerDemographics)
                .WithMany(x => x.Customers)
                .Map(m => m.MapLeftKey("CustomerID")
                        .MapRightKey("CustomerTypeID")
                        .ToTable("CustomerCustomerDemo"));
        }
    }
}
