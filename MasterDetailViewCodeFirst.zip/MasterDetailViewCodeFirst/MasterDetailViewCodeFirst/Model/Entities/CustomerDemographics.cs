﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MasterDetailViewCodeFirst.Model.Entities
{
    public class CustomerDemographics
    {
        [Key]
        public string CustomerTypeID { get; set; }
        public string CustomerDesc { get; set; }

        public virtual ICollection<Customers> Customers { get; set; }
    }
}
